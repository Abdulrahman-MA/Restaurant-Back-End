# Qaser_El_Kbabgi
Full mobile application for Qaser el kbabgi restaurant tech for mobile app =>Flutter , backend tech => python 
